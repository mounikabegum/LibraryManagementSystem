package strategy;

import model.Loan;

public interface FineStrategy {
    double calculateFine(Loan loan);
}
