package strategy;

import model.Loan;

public class SimpleFineStrategy implements FineStrategy {
    private double finePerDay;

    public SimpleFineStrategy(double finePerDay) {
        this.finePerDay = finePerDay;
    }

    @Override
    public double calculateFine(Loan loan) {
        return finePerDay * loan.getOverdueDays();
    }
}
