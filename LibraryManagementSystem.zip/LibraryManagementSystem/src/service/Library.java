package service;

import model.BookItem;
import model.Loan;
import model.Member;
import strategy.FineStrategy;

import java.util.ArrayList;
import java.util.List;

public class Library {

    private List<Loan> loans = new ArrayList<>();
    private FineStrategy fineStrategy;

    public Library(FineStrategy fineStrategy) {
        this.fineStrategy = fineStrategy;
    }

    public void addBookItem(BookItem bookItem) {
        // optional if you want to keep track
    }

    public boolean issueBook(BookItem bookItem, Member member, int loanDays) {
        if (!bookItem.isAvailable()) return false;

        Loan loan = new Loan(bookItem, member, loanDays);
        loans.add(loan);
        member.addLoan(loan);
        bookItem.markIssued();
        return true;
    }

    public double returnBook(BookItem bookItem, Member member) {
        for (Loan loan : member.getLoans()) {
            if (loan.getBookItem().equals(bookItem)) {
                loan.returnBook();
                loans.remove(loan);
                return fineStrategy.calculateFine(loan);
            }
        }
        return 0.0;
    }

    public List<BookItem> getAvailableBooks() {
        List<BookItem> available = new ArrayList<>();
        for (Loan loan : loans) {
            BookItem b = loan.getBookItem();
            if (b.isAvailable()) available.add(b);
        }
        return available;
    }
}
