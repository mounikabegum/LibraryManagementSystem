import model.BookItem;
import model.Member;
import service.Library;
import strategy.FineStrategy;
import strategy.SimpleFineStrategy;

public class Main {

    public static void main(String[] args) {
        // 1️⃣ Create a Fine Strategy
        FineStrategy fineStrategy = new SimpleFineStrategy(5.0); // 5 currency units per day late

        // 2️⃣ Create a Library with this strategy
        Library library = new Library(fineStrategy);

        // 3️⃣ Add books to the library
        BookItem book1 = new BookItem("B001", "The Alchemist");
        BookItem book2 = new BookItem("B002", "Clean Code");
        BookItem book3 = new BookItem("B003", "Design Patterns");

        library.addBookItem(book1);
        library.addBookItem(book2);
        library.addBookItem(book3);

        // 4️⃣ Create a member
        Member member1 = new Member("M001", "Mounika");

        // 5️⃣ Issue books to member
        boolean issued1 = library.issueBook(book1, member1, 7); // 7 days loan
        boolean issued2 = library.issueBook(book2, member1, 5); // 5 days loan

        System.out.println("Issued The Alchemist: " + issued1);
        System.out.println("Issued Clean Code: " + issued2);

        // 6️⃣ Show available books after issuing
        System.out.println("\nAvailable books after issuing:");
        for (BookItem b : library.getAvailableBooks()) {
            System.out.println(b.getTitle());
        }

        // 7️⃣ Return a book (simulate late return)
        // For demo, let's pretend 3 days late
        double fine = library.returnBook(book1, member1);
        System.out.println("\nReturned The Alchemist. Fine: " + fine);

        // 8️⃣ Available books after returning
        System.out.println("\nAvailable books after returning:");
        for (BookItem b : library.getAvailableBooks()) {
            System.out.println(b.getTitle());
        }
    }
}
