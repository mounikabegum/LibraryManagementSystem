package model;

public enum BookStatus {
    AVAILABLE,
    ISSUED
}
