package model;

public class BookItem {
    private String id;
    private String title;
    private boolean isAvailable = true;

    public BookItem(String id, String title) {
        this.id = id;
        this.title = title;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void markIssued() {
        this.isAvailable = false;
    }

    public void markAvailable() {
        this.isAvailable = true;
    }
}
