package model;

import java.time.LocalDate;

public class Loan {
    private BookItem bookItem;
    private Member member;
    private LocalDate dueDate;
    private LocalDate returnDate;

    public Loan(BookItem bookItem, Member member, int loanDays) {
        this.bookItem = bookItem;
        this.member = member;
        this.dueDate = LocalDate.now().plusDays(loanDays);
    }

    public BookItem getBookItem() {
        return bookItem;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }

    public int getOverdueDays() {
        if (returnDate == null) return 0;
        int daysLate = (int) (returnDate.toEpochDay() - dueDate.toEpochDay());
        return Math.max(daysLate, 0);
    }

    // ✅ New method to fix Library.java error
    public void returnBook() {
        this.returnDate = LocalDate.now();
        bookItem.markAvailable();
    }
}
